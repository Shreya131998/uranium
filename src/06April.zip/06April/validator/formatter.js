let string1=" FunctionUp ".trim()
let string2="Shreya".toLowerCase()
let string3="Shreya".toUpperCase()
module.exports.string1=string1
module.exports.string2=string2
module.exports.string3=string3
